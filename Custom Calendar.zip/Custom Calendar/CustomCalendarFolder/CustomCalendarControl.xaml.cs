﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Custom_Calendar.CustomCalendarFolder;
using Windows.UI;

// The User Control item template is documented at https://go.microsoft.com/fwlink/?LinkId=234236

namespace Custom_Calendar.CustomCalendarFolder
{
    public sealed partial class CustomCalendarControl : UserControl
    {
        public CustomCalendarControl()
        {
            this.InitializeComponent();
            generateMonth();
        }
        DateTime dateTime = DateTime.Today;
        public void generateMonth()
        {
            Months.SelectionChanged -= changingMonth;
            string month = dateTime.ToString("MMMM");
            string year = dateTime.ToString("yyyy");
            Year.Text = year;
            choosingMonth(month);
            DateTime firstDay = new DateTime(dateTime.Year, dateTime.Month, 1);
            string day = firstDay.DayOfWeek.ToString();
            int i = 0;
            if (day == "Sunday") i = 0;
            else if (day == "Monday") i = 1;
            else if (day == "Tuesday") i = 2;
            else if (day == "Wednesday") i = 3;
            else if (day == "Thursday") i = 4;
            else if (day == "Friday") i = 5;
            else if (day == "Saturday") i = 6;

            DateTime date = firstDay.AddDays(-i);

            foreach (Grid grid in CalendarCells.Children)
            {
                CustomCalendarCell cell = grid.Children[0] as CustomCalendarCell;

                string todayDate = DateTime.Now.Date.ToString();
                if (date.Date == DateTime.Now.Date)
                {
                    cell.mainStackPanel.Background = new SolidColorBrush(Colors.LightYellow);
                }
                else cell.mainStackPanel.Background = new SolidColorBrush(Colors.Transparent);
                if (date.Date.Month == firstDay.Date.Month) cell.visibleDate.Foreground = new SolidColorBrush(Colors.Black);
                else cell.visibleDate.Foreground = new SolidColorBrush(Colors.DarkGray);
                cell.visibleDate.Text = date.Date.ToString("dd");
                cell.collapsedDate.Text = date.Date.ToString();
                date = date.AddDays(1);
            }
            Months.SelectionChanged += changingMonth;
        }

        public void choosingMonth(string month)
        {
            if (month == "January") Months.SelectedIndex = 0;
            else if (month == "February") Months.SelectedIndex = 1;
            else if (month == "March") Months.SelectedIndex = 2;
            else if (month == "April") Months.SelectedIndex = 3;
            else if (month == "May") Months.SelectedIndex = 4;
            else if (month == "June") Months.SelectedIndex = 5;
            else if (month == "July") Months.SelectedIndex = 6;
            else if (month == "August") Months.SelectedIndex = 7;
            else if (month == "September") Months.SelectedIndex = 8;
            else if (month == "October") Months.SelectedIndex = 9;
            else if (month == "November") Months.SelectedIndex = 10;
            else if (month == "December") Months.SelectedIndex = 11;
        }

        private void navMonthBack(object sender, TappedRoutedEventArgs e)
        {
            dateTime = dateTime.AddMonths(-1);
            generateMonth();
        }

        private void navMonthForward(object sender, TappedRoutedEventArgs e)
        {
            //clearDatesInCells();
            dateTime = dateTime.AddMonths(1);
            generateMonth();
        }

        private void clearDatesInCells()
        {
            foreach (Grid grid in CalendarCells.Children)
            {
                CustomCalendarCell cell = grid.Children[0] as CustomCalendarCell;
                cell.visibleDate.Text = "";
                cell.collapsedDate.Text = "";
            }
        }

        private void changingMonth(object sender, SelectionChangedEventArgs e)
        {
            if (CalendarCells != null)
            {
                ComboBoxItem item = (sender as ComboBox).SelectedItem as ComboBoxItem;
                int i = Convert.ToInt32(item.Name.Replace("M", ""));
                dateTime = new DateTime(dateTime.Year, i, 1);
                generateMonth();
            }
        }

        private void navYearBack(object sender, TappedRoutedEventArgs e)
        {
            dateTime = dateTime.AddYears(-1);
            generateMonth();
        }

        private void navYearForward(object sender, TappedRoutedEventArgs e)
        {
            dateTime = dateTime.AddYears(1);
            generateMonth();
        }

        private void setToCurrent(object sender, TappedRoutedEventArgs e)
        {
            dateTime = DateTime.Now;
            generateMonth();
        }
    }
}
